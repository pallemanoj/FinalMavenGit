# mule-cicdwithjenkins
This is a sample mule application with maven configuration for deployment to cloudhub

### Configurations:
Use mvn clean deploy -Dcloudhubusername="your cloudhub username" -Dcloudhubpassword="your cloudhub password"

		
###
More details can be found at the blog post: http://rumanblogs.com/mulesoft-dallas-meetup-cicd-with-jenkins/
  
### Contributing
All pull requests are welcome
